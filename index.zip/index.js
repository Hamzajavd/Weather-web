const date = new Date();
let day = date.getDate();
const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const months = ["jan", "feb", "Mar", "April", "May", "Jun", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];

function formatTime(timestamp) {
    const date = new Date();
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

function getWeather() {
    let city = document.querySelector("#searchbar").value;
    let API_key = "9f8bc391ed32f4907fb11d38547fe1a1"
    axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_key}&units=metric`)
        .then(function (response) {
            console.log(response);
            document.querySelector("#Current h1").innerHTML = `${Math.round(response.data.main.temp)}°C`;
            document.querySelector(".Sunrise").innerHTML = `Sunrise: ${formatTime(response.data.sys.sunrise)}`;
            document.querySelector("#Sunset").innerHTML = `Sunset: ${formatTime(response.data.sys.sunset)}`;
            document.querySelector(".Date").innerHTML = `Date: ${day} - ${months[date.getMonth()]} - ${date.getFullYear()}`;
            document.querySelector("#heading").innerHTML = `${days[date.getDay()]}`;
            document.querySelector(".sun").src = `https://openweathermap.org/img/wn/${response.data.weather[0].icon}@2x.png`;
        })
        .catch(function (error) {
            console.log(error.message);
            
        });
}

function getCurrentLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;
            let API_key = "9f8bc391ed32f4907fb11d38547fe1a1";
            
            axios.get(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${API_key}&units=metric`)
                .then(function (response) {
                    console.log(response);
                    document.querySelector("#Current h1").innerHTML = `${Math.round(response.data.main.temp)}°C`;
                    document.querySelector(".Sunrise").innerHTML = `Sunrise: ${formatTime(response.data.sys.sunrise)}`;
                    document.querySelector("#Sunset").innerHTML = `Sunset: ${formatTime(response.data.sys.sunset)}`;
                    document.querySelector(".Date").innerHTML = `Date: ${day} - ${months[date.getMonth()]} - ${date.getFullYear()}`;
                    document.querySelector("#heading").innerHTML = `${days[date.getDay()]}`;
                    document.querySelector(".sun").src = `https://openweathermap.org/img/wn/${response.data.weather[0].icon}@2x.png`;
                })
                .catch(function (error) {
                    console.log(error.message);
                  
                });
        }, (error) => {
            alert("Unable to get your location");
        });
    } else {
        alert("Geolocation is not supported by your browser");
    }
}

// Chart data
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('myChart');

    // Create the initial chart
    const myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Wind Speed km/hr',
                data: [12, 19, 3, 5, 2, 3],
                borderWidth: 1,
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Function to add data dynamically to the chart
    function addData(chart, label, data) {
        chart.data.labels.push(label);
        chart.data.datasets[0].data.push(data);
        chart.update();
    }

    // Function to remove the oldest data point
    function removeOldData(chart) {
        chart.data.labels.shift();
        chart.data.datasets[0].data.shift();
        chart.update();
    }

    // Update chart every 2 seconds
    setInterval(() => {
        const randomValue = Math.floor(Math.random() * 20);
        const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        if (myChart.data.labels.length >= 10) {
            removeOldData(myChart);
        }

        addData(myChart, currentTime, randomValue);
    }, 2000);
});

// Slider toggle
function toggleSidebar() {
    let sidebar = document.querySelector('.sidebar');
    let toggleButton = document.querySelector('.toggle-btn');
    sidebar.classList.toggle('open');
    toggleButton.classList.toggle('active');
}
